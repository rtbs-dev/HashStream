// example of program that calculates the average degree of hashtags
